"use client";

export const TOKEN_KEY = "talbista.auth.token";
export const USER_KEY = "talbista.auth.user";

export type SessionUser = { id: number; phone: string; createdAt?: string };
type ApiOptions = { method?: string; body?: unknown; token?: string | null };

export async function apiFetch(path: string, options: ApiOptions = {}) {
  const token = options.token === undefined ? getToken() : options.token;
  const response = await fetch(path, {
    method: options.method ?? (options.body ? "POST" : "GET"),
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });
  const data = (await response.json().catch(() => null)) as
    | { ok?: boolean; error?: string; user?: SessionUser; token?: string }
    | null;
  if (!data) throw new Error("تعذر الاتصال بالخادم.");
  return data;
}

export function getToken(): string | null {
  try { return localStorage.getItem(TOKEN_KEY); } catch { return null; }
}
export function getStoredUser(): SessionUser | null {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? (JSON.parse(raw) as SessionUser) : null;
  } catch { return null; }
}
export function setSession(token: string, user: SessionUser) {
  localStorage.setItem(TOKEN_KEY, token);
  localStorage.setItem(USER_KEY, JSON.stringify(user));
}
export function clearSession() {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(USER_KEY);
}
