"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import {
  apiFetch, clearSession, getToken, setSession, type SessionUser,
} from "@/lib/auth-client";

export default function LoginPage() {
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [user, setUser] = useState<SessionUser | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      const token = getToken();
      if (!token) return;
      try {
        const result = await apiFetch("/api/auth/me", { token });
        if (alive && result.ok && result.user) setUser(result.user);
        else clearSession();
      } catch { clearSession(); }
    })();
    return () => { alive = false; };
  }, []);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true); setError(null);
    try {
      const result = await apiFetch("/api/auth/login", { method: "POST", body: { phone, password } });
      if (!result.ok || !result.token || !result.user) throw new Error(result.error || "تعذر تسجيل الدخول.");
      setSession(result.token, result.user);
      setUser(result.user);
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر تسجيل الدخول.");
    } finally { setBusy(false); }
  };

  return (
    <main className="relative min-h-screen grid place-items-center px-4 py-10">
      <div className="lux-scene" aria-hidden>
        <div className="lux-orb royal" />
        <div className="lux-orb gold" />
        <div className="lux-grid" />
      </div>

      <section className="lux-card">
        <Image className="logo-img" src="/logo.png" alt="طلبيستا" width={150} height={150} priority />
        {user ? (
          <div className="session-box">
            <p className="sub-gold" style={{ fontSize: 17 }}>أهلاً بعودتك 👑</p>
            <span className="phone-n">{user.phone}</span>
            <button className="gold-btn" onClick={() => { clearSession(); setUser(null); }}>تسجيل الخروج</button>
            <p className="switch">الجلسة فعّالة · <Link href="/register">إنشاء حساب آخر</Link></p>
          </div>
        ) : (
          <>
            <p className="sub-gold" style={{ fontSize: 17 }}>تسجيل الدخول</p>
            <p className="sub-dim">بوابتك إلى عالم التوصيل الفاخر</p>
            {error && <p className="error">{error}</p>}
            <form onSubmit={submit}>
              <label className="field">
                <span>رقم الهاتف</span>
                <input dir="ltr" inputMode="tel" autoComplete="tel" placeholder="+2189XXXXXXXX"
                  value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </label>
              <label className="field">
                <span>كلمة المرور</span>
                <input type="password" dir="ltr" autoComplete="current-password"
                  value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
              </label>
              <button className="gold-btn" disabled={busy}>{busy ? "جارٍ التحقق…" : "دخول"}</button>
            </form>
            <p className="switch">ليس لديك حساب؟ <Link href="/register">إنشاء حساب فاخر</Link></p>
          </>
        )}
      </section>

      <footer className="kimi-credit">Designed with 💚 by <b>Kimi</b> · طلبيستا 2027</footer>
    </main>
  );
}
