"use client";

import { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { apiFetch, setSession } from "@/lib/auth-client";

export default function RegisterPage() {
  const router = useRouter();
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const submit = async (event: React.FormEvent) => {
    event.preventDefault();
    setBusy(true); setError(null);
    try {
      const result = await apiFetch("/api/auth/register", { method: "POST", body: { phone, password } });
      if (!result.ok || !result.token || !result.user) throw new Error(result.error || "تعذر إنشاء الحساب.");
      setSession(result.token, result.user);
      router.push("/login");
    } catch (err) {
      setError(err instanceof Error ? err.message : "تعذر إنشاء الحساب.");
    } finally { setBusy(false); }
  };

  return (
    <main className="relative min-h-screen grid place-items-center px-4 py-10">
      <div className="lux-scene" aria-hidden>
        <div className="lux-orb royal" />
        <div className="lux-orb gold" />
        <div className="lux-grid" />
      </div>

      <section className="lux-card">
        <Image className="logo-img" src="/logo.png" alt="طلبيستا" width={150} height={150} priority />
        <p className="sub-gold" style={{ fontSize: 17 }}>عضوية جديدة</p>
        <p className="sub-dim">انضم إلى النخبة — التوصيل بلمسة ملكية</p>
        {error && <p className="error">{error}</p>}
        <form onSubmit={submit}>
          <label className="field">
            <span>رقم الهاتف</span>
            <input dir="ltr" inputMode="tel" autoComplete="tel" placeholder="+2189XXXXXXXX"
              value={phone} onChange={(e) => setPhone(e.target.value)} required />
          </label>
          <label className="field">
            <span>كلمة المرور (8 أحرف فأكثر)</span>
            <input type="password" dir="ltr" autoComplete="new-password"
              value={password} onChange={(e) => setPassword(e.target.value)} required minLength={8} />
          </label>
          <button className="gold-btn" disabled={busy}>{busy ? "جارٍ الإنشاء…" : "إنشاء الحساب"}</button>
        </form>
        <p className="switch">لديك حساب؟ <Link href="/login">تسجيل الدخول</Link></p>
      </section>

      <footer className="kimi-credit">Designed with 💚 by <b>Kimi</b> · طلبيستا 2027</footer>
    </main>
  );
}
